package com.mobevolution;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mojang.logging.LogUtils;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.DefaultAttributes;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

/**
 * Configuracion individual por mob (estadisticas por nivel y nivel maximo).
 * Se guarda en config/mobevolution-mobs.json y se edita con /mobevolution config mob ...
 */
public final class MobOverrides {
    private static final Logger LOGGER = LogUtils.getLogger();

    /** Las 4 estadisticas que suben por nivel. */
    public enum Stat {
        HEALTH("health", 10.0),
        DAMAGE("damage", 10.0),
        SPEED("speed", 1.0),
        ARMOR("armor", 10.0);

        public final String key;
        public final double max;

        Stat(String key, double max) { this.key = key; this.max = max; }

        public ForgeConfigSpec.DoubleValue global() {
            return switch (this) {
                case HEALTH -> Config.HEALTH_COEF;
                case DAMAGE -> Config.DAMAGE_COEF;
                case SPEED -> Config.SPEED_COEF;
                case ARMOR -> Config.ARMOR_COEF;
            };
        }
    }

    public static final class Entry {
        public Integer maxLevel;
        public Double health, damage, speed, armor;

        Double get(Stat s) {
            return switch (s) {
                case HEALTH -> health;
                case DAMAGE -> damage;
                case SPEED -> speed;
                case ARMOR -> armor;
            };
        }

        void set(Stat s, Double v) {
            switch (s) {
                case HEALTH -> health = v;
                case DAMAGE -> damage = v;
                case SPEED -> speed = v;
                case ARMOR -> armor = v;
            }
        }

        boolean isEmpty() {
            return maxLevel == null && health == null && damage == null && speed == null && armor == null;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type TYPE = new TypeToken<Map<String, Entry>>() {}.getType();
    private static final Map<ResourceLocation, Entry> MAP = new TreeMap<>();
    private static boolean loaded = false;

    private MobOverrides() {}

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("mobevolution-mobs.json");
    }

    public static synchronized void load() {
        MAP.clear();
        Path f = file();
        if (Files.exists(f)) {
            try (Reader r = Files.newBufferedReader(f)) {
                Map<String, Entry> raw = GSON.fromJson(r, TYPE);
                if (raw != null) {
                    raw.forEach((k, v) -> {
                        ResourceLocation id = ResourceLocation.tryParse(k);
                        if (id != null && v != null && !v.isEmpty()) MAP.put(id, v);
                    });
                }
            } catch (Exception ex) {
                LOGGER.error("[MobEvolution] No se pudo leer {}", f, ex);
            }
        }
        loaded = true;
    }

    private static synchronized void save() {
        Map<String, Entry> raw = new TreeMap<>();
        MAP.forEach((k, v) -> raw.put(k.toString(), v));
        try (Writer w = Files.newBufferedWriter(file())) {
            GSON.toJson(raw, TYPE, w);
        } catch (Exception ex) {
            LOGGER.error("[MobEvolution] No se pudo guardar {}", file(), ex);
        }
    }

    private static void ensureLoaded() {
        if (!loaded) load();
    }

    // ---------------------------------------------------------------- lectura

    public static synchronized Entry get(ResourceLocation id) {
        ensureLoaded();
        return MAP.get(id);
    }

    public static boolean has(ResourceLocation id) { return get(id) != null; }

    public static Integer maxLevel(ResourceLocation id) {
        Entry e = get(id);
        return e == null ? null : e.maxLevel;
    }

    public static Double custom(ResourceLocation id, Stat s) {
        Entry e = get(id);
        return e == null ? null : e.get(s);
    }

    /** Coeficiente por nivel efectivo: el del mob si lo tiene, si no el global. */
    public static double coef(ResourceLocation id, Stat s) {
        Double c = id == null ? null : custom(id, s);
        return c != null ? c : s.global().get();
    }

    // ---------------------------------------------------------------- escritura

    public static synchronized void setStat(ResourceLocation id, Stat s, Double value) {
        ensureLoaded();
        Entry e = MAP.computeIfAbsent(id, k -> new Entry());
        e.set(s, value);
        cleanup(id, e);
        save();
    }

    public static synchronized void setMaxLevel(ResourceLocation id, Integer value) {
        ensureLoaded();
        Entry e = MAP.computeIfAbsent(id, k -> new Entry());
        e.maxLevel = value;
        cleanup(id, e);
        save();
    }

    public static synchronized void reset(ResourceLocation id) {
        ensureLoaded();
        if (MAP.remove(id) != null) save();
    }

    private static void cleanup(ResourceLocation id, Entry e) {
        if (e.isEmpty()) MAP.remove(id);
    }

    // ---------------------------------------------------------------- lista de mobs

    /** Todos los mobs (vanilla y de mods) que tienen atributos, ordenados por id. */
    @SuppressWarnings("unchecked")
    public static List<ResourceLocation> configurableIds() {
        List<ResourceLocation> out = new ArrayList<>();
        for (Map.Entry<net.minecraft.resources.ResourceKey<EntityType<?>>, EntityType<?>> en : ForgeRegistries.ENTITY_TYPES.getEntries()) {
            EntityType<?> t = en.getValue();
            if (t == EntityType.PLAYER || t == EntityType.ARMOR_STAND) continue;
            try {
                if (DefaultAttributes.hasSupplier((EntityType<? extends LivingEntity>) t)) out.add(en.getKey().location());
            } catch (Throwable ignored) {
                // entidad rara de algun mod: se omite
            }
        }
        out.sort(ResourceLocation::compareTo);
        return out;
    }
}
