package com.mobevolution;

import com.mobevolution.MobOverrides.Stat;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * /mobevolution days ...   -> dias / nivel minimo
 * /mobevolution config ... -> estadisticas por nivel (global e individual) y nivel maximo por mob
 * Requiere permiso de operador (nivel 2).
 */
public class MobCommands {
    private static final int PAGE_SIZE = 10;

    private static final SuggestionProvider<CommandSourceStack> MOB_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggestResource(MobOverrides.configurableIds(), builder);

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        MobOverrides.load();
    }

    @SubscribeEvent
    public void onRegister(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("mobevolution")
                        .requires(s -> s.hasPermission(2))
                        .then(days())
                        .then(config()));
    }

    // ================================================================ /mobevolution days

    private LiteralArgumentBuilder<CommandSourceStack> days() {
        return Commands.literal("days")
                .then(Commands.literal("get").executes(c -> daysGet(c.getSource())))
                .then(Commands.literal("reset").executes(c -> daysSet(c.getSource(), 0.0)))
                .then(Commands.literal("add")
                        .then(Commands.argument("dias", DoubleArgumentType.doubleArg(-100000.0, 100000.0))
                                .executes(c -> daysAdd(c.getSource(), DoubleArgumentType.getDouble(c, "dias")))))
                .then(Commands.literal("set")
                        .then(Commands.argument("dias", DoubleArgumentType.doubleArg(0.0, 100000.0))
                                .executes(c -> daysSet(c.getSource(), DoubleArgumentType.getDouble(c, "dias")))))
                .then(Commands.literal("minlevel")
                        .then(Commands.argument("nivel", IntegerArgumentType.integerArg(1, 1000))
                                .executes(c -> daysMinLevel(c.getSource(), IntegerArgumentType.getInteger(c, "nivel")))));
    }

    private static int daysGet(CommandSourceStack src) {
        MinecraftServer server = src.getServer();
        double real = DayOffsetData.realDays(server);
        double off = DayOffsetData.get(server).getOffset();
        double eff = DayOffsetData.effectiveDays(server);
        int min = MobScalingHandler.minLevelForDays(eff);
        int max = Math.max(min, (int) Math.ceil(min * Config.MAX_MULTIPLIER.get()));
        String msg = String.format(Locale.ROOT,
                "[MobEvolution] Dias reales: %.2f | Desplazamiento: %+.2f | Dias efectivos: %.2f\n"
                        + "Nivel minimo actual: %d | Nivel maximo del momento: %d",
                real, off, eff, min, max);
        src.sendSuccess(() -> Component.literal(msg), false);
        return min;
    }

    private static int daysSet(CommandSourceStack src, double days) {
        DayOffsetData.setEffectiveDays(src.getServer(), days);
        return daysChanged(src);
    }

    private static int daysAdd(CommandSourceStack src, double days) {
        DayOffsetData.addDays(src.getServer(), days);
        return daysChanged(src);
    }

    /** Fija los dias para que el nivel minimo sea exactamente el indicado. */
    private static int daysMinLevel(CommandSourceStack src, int level) {
        // +0.01 para evitar que un error de redondeo de doubles reste un nivel
        DayOffsetData.setEffectiveDays(src.getServer(), level * Config.DAYS_PER_LEVEL.get() + 0.01);
        return daysChanged(src);
    }

    private static int daysChanged(CommandSourceStack src) {
        double eff = DayOffsetData.effectiveDays(src.getServer());
        int min = MobScalingHandler.minLevelForDays(eff);
        String msg = String.format(Locale.ROOT,
                "[MobEvolution] Dias efectivos: %.2f -> nivel minimo %d (afecta a los mobs que aparezcan a partir de ahora)", eff, min);
        src.sendSuccess(() -> Component.literal(msg).withStyle(ChatFormatting.GREEN), true);
        return min;
    }

    // ================================================================ /mobevolution config

    private LiteralArgumentBuilder<CommandSourceStack> config() {
        // ---- global
        LiteralArgumentBuilder<CommandSourceStack> global = Commands.literal("global")
                .executes(c -> globalShow(c.getSource()));
        for (Stat s : Stat.values()) {
            global.then(Commands.literal(s.key)
                    .then(Commands.argument("valor", DoubleArgumentType.doubleArg(0.0, s.max))
                            .executes(c -> globalSet(c.getSource(), s, DoubleArgumentType.getDouble(c, "valor")))));
        }

        // ---- individual
        var mobNode = Commands.argument("mob", ResourceLocationArgument.id())
                .suggests(MOB_SUGGESTIONS)
                .executes(c -> mobInfo(c.getSource(), mob(c)));
        for (Stat s : Stat.values()) {
            mobNode.then(Commands.literal(s.key)
                    .then(Commands.argument("valor", DoubleArgumentType.doubleArg(0.0, s.max))
                            .executes(c -> mobSet(c.getSource(), mob(c), s, DoubleArgumentType.getDouble(c, "valor"))))
                    .then(Commands.literal("reset")
                            .executes(c -> mobSet(c.getSource(), mob(c), s, null))));
        }
        mobNode.then(Commands.literal("maxlevel")
                .then(Commands.argument("nivel", IntegerArgumentType.integerArg(1, 1000))
                        .executes(c -> mobMaxLevel(c.getSource(), mob(c), IntegerArgumentType.getInteger(c, "nivel"))))
                .then(Commands.literal("reset")
                        .executes(c -> mobMaxLevel(c.getSource(), mob(c), null))));
        mobNode.then(Commands.literal("reset").executes(c -> mobResetAll(c.getSource(), mob(c))));

        return Commands.literal("config")
                .then(global)
                .then(Commands.literal("mob").then(mobNode))
                .then(Commands.literal("list")
                        .executes(c -> list(c.getSource(), "", 1))
                        .then(Commands.argument("pagina", IntegerArgumentType.integerArg(1))
                                .executes(c -> list(c.getSource(), "", IntegerArgumentType.getInteger(c, "pagina")))))
                .then(Commands.literal("search")
                        .then(Commands.argument("texto", StringArgumentType.word())
                                .executes(c -> list(c.getSource(), StringArgumentType.getString(c, "texto"), 1))
                                .then(Commands.argument("pagina", IntegerArgumentType.integerArg(1))
                                        .executes(c -> list(c.getSource(), StringArgumentType.getString(c, "texto"),
                                                IntegerArgumentType.getInteger(c, "pagina"))))))
                .then(Commands.literal("reload").executes(c -> {
                    MobOverrides.load();
                    c.getSource().sendSuccess(() -> Component.literal("[MobEvolution] mobevolution-mobs.json recargado"), true);
                    return 1;
                }));
    }

    private static ResourceLocation mob(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ResourceLocation id = ResourceLocationArgument.getId(c, "mob");
        if (!ForgeRegistries.ENTITY_TYPES.containsKey(id)) {
            throw new SimpleCommandExceptionType(Component.literal("Mob desconocido: " + id)).create();
        }
        return id;
    }

    private static String fmt(double v) {
        return String.format(Locale.ROOT, "%.4f", v);
    }

    // ---------------------------------------------------------------- global

    private static int globalShow(CommandSourceStack src) {
        StringBuilder sb = new StringBuilder("[MobEvolution] Estadisticas globales por nivel:");
        for (Stat s : Stat.values()) sb.append("\n  ").append(s.key).append(" = ").append(fmt(s.global().get()));
        sb.append("\nUsa /mobevolution config global <health|damage|speed|armor> <valor>");
        String msg = sb.toString();
        src.sendSuccess(() -> Component.literal(msg), false);
        return 1;
    }

    private static int globalSet(CommandSourceStack src, Stat s, double value) {
        s.global().set(value);
        s.global().save();
        src.sendSuccess(() -> Component.literal("[MobEvolution] Global " + s.key + " por nivel = " + fmt(value)
                + " (afecta a los mobs que aparezcan a partir de ahora)").withStyle(ChatFormatting.GREEN), true);
        return 1;
    }

    // ---------------------------------------------------------------- individual

    private static int mobInfo(CommandSourceStack src, ResourceLocation id) {
        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(id);
        boolean boss = BossRules.isBoss(type);
        String kind;
        if (id.equals(BossRules.WARDEN)) kind = "Warden (siempre nivel 1 salvo configuracion propia)";
        else if (boss) kind = BossRules.isVanillaBoss(type) ? "Jefe de Minecraft" : "Jefe de mod";
        else kind = "Mob normal";

        Integer customMax = MobOverrides.maxLevel(id);
        StringBuilder sb = new StringBuilder("[MobEvolution] ").append(id).append("\n  Tipo: ").append(kind);
        sb.append("\n  Nivel maximo: ").append(BossRules.maxLevel(type)).append(customMax != null ? " (personalizado)" : "");
        for (Stat s : Stat.values()) {
            Double custom = MobOverrides.custom(id, s);
            sb.append("\n  ").append(s.key).append(" por nivel: ").append(fmt(MobOverrides.coef(id, s)))
                    .append(custom != null ? " (personalizado)" : " (global)");
        }
        String msg = sb.toString();
        src.sendSuccess(() -> Component.literal(msg), false);
        return 1;
    }

    private static int mobSet(CommandSourceStack src, ResourceLocation id, Stat s, Double value) {
        MobOverrides.setStat(id, s, value);
        String msg = value == null
                ? "[MobEvolution] " + id + ": " + s.key + " vuelve al valor global (" + fmt(s.global().get()) + ")"
                : "[MobEvolution] " + id + ": " + s.key + " por nivel = " + fmt(value);
        src.sendSuccess(() -> Component.literal(msg).withStyle(ChatFormatting.GREEN), true);
        return 1;
    }

    private static int mobMaxLevel(CommandSourceStack src, ResourceLocation id, Integer level) {
        MobOverrides.setMaxLevel(id, level);
        int now = BossRules.maxLevel(ForgeRegistries.ENTITY_TYPES.getValue(id));
        String msg = level == null
                ? "[MobEvolution] " + id + ": nivel maximo restablecido (ahora " + now + ")"
                : "[MobEvolution] " + id + ": nivel maximo = " + level;
        src.sendSuccess(() -> Component.literal(msg).withStyle(ChatFormatting.GREEN), true);
        return 1;
    }

    private static int mobResetAll(CommandSourceStack src, ResourceLocation id) {
        MobOverrides.reset(id);
        src.sendSuccess(() -> Component.literal("[MobEvolution] " + id + ": configuracion individual borrada")
                .withStyle(ChatFormatting.GREEN), true);
        return 1;
    }

    // ---------------------------------------------------------------- lista de mobs

    private static int list(CommandSourceStack src, String filter, int page) {
        String f = filter.toLowerCase(Locale.ROOT);
        List<ResourceLocation> ids = MobOverrides.configurableIds().stream()
                .filter(id -> f.isEmpty() || id.toString().contains(f))
                .collect(Collectors.toList());
        int pages = Math.max(1, (ids.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        int p = Math.min(page, pages);

        src.sendSuccess(() -> Component.literal("===== Mobs (" + ids.size() + ")"
                + (f.isEmpty() ? "" : " filtro '" + f + "'") + " - pagina " + p + "/" + pages
                + " - clic en un mob para configurarlo =====").withStyle(ChatFormatting.GOLD), false);

        for (int i = (p - 1) * PAGE_SIZE; i < Math.min(ids.size(), p * PAGE_SIZE); i++) {
            ResourceLocation id = ids.get(i);
            EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(id);
            MutableComponent line = Component.literal(id.toString()).withStyle(st -> st
                    .withColor(ChatFormatting.AQUA)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/mobevolution config mob " + id + " "))
                    .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Clic para configurar"))));
            line.append(Component.literal("  nivel max " + BossRules.maxLevel(type)).withStyle(ChatFormatting.GRAY));
            if (BossRules.isBoss(type)) line.append(Component.literal("  [JEFE]").withStyle(ChatFormatting.RED));
            if (MobOverrides.has(id)) line.append(Component.literal("  [personalizado]").withStyle(ChatFormatting.GREEN));
            src.sendSuccess(() -> line, false);
        }

        String base = "/mobevolution config " + (f.isEmpty() ? "list " : "search " + f + " ");
        MutableComponent nav = Component.literal("");
        if (p > 1) nav.append(Component.literal("[< anterior] ").withStyle(st -> st.withColor(ChatFormatting.YELLOW)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, base + (p - 1)))));
        if (p < pages) nav.append(Component.literal("[siguiente >]").withStyle(st -> st.withColor(ChatFormatting.YELLOW)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, base + (p + 1)))));
        src.sendSuccess(() -> nav, false);
        return ids.size();
    }
}
