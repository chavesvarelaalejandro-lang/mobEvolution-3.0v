package com.mobevolution;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Desplazamiento de dias guardado en el mundo. Los comandos /mobevolution days ... lo modifican
 * sin tocar la hora real del mundo: dias efectivos = dias reales del Overworld + offset.
 */
public class DayOffsetData extends SavedData {
    private static final String NAME = "mobevolution_days";
    private double offset = 0.0;

    public static DayOffsetData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(DayOffsetData::load, DayOffsetData::new, NAME);
    }

    public static DayOffsetData load(CompoundTag tag) {
        DayOffsetData d = new DayOffsetData();
        d.offset = tag.getDouble("offset");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putDouble("offset", offset);
        return tag;
    }

    public double getOffset() { return offset; }

    public static double realDays(MinecraftServer server) {
        return server.overworld().getDayTime() / 24000.0;
    }

    /** Dias que usa el mod para calcular el nivel minimo (nunca negativo). */
    public static double effectiveDays(MinecraftServer server) {
        return Math.max(0.0, realDays(server) + get(server).offset);
    }

    /** Fija los dias efectivos a un valor concreto. */
    public static void setEffectiveDays(MinecraftServer server, double days) {
        DayOffsetData d = get(server);
        d.offset = Math.max(0.0, days) - realDays(server);
        d.setDirty();
    }

    public static void addDays(MinecraftServer server, double days) {
        setEffectiveDays(server, effectiveDays(server) + days);
    }
}
