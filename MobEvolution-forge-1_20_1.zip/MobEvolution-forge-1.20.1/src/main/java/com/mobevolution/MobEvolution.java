package com.mobevolution;

import com.mobevolution.network.Network;
import com.mobevolution.skills.SkillEvents;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MobEvolution.MODID)
public class MobEvolution {
    public static final String MODID = "mobevolution";

    public MobEvolution() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        bus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.register(new MobScalingHandler());
        MinecraftForge.EVENT_BUS.register(new SkillEvents());
        MinecraftForge.EVENT_BUS.register(new MobCommands());
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(Network::register);
    }
}
