package com.mobevolution;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.common.Tags;
import net.minecraftforge.registries.ForgeRegistries;

/** Deteccion de jefes y calculo del nivel maximo permitido de cada entidad. */
public final class BossRules {
    public static final ResourceLocation WARDEN = new ResourceLocation("minecraft", "warden");

    private BossRules() {}

    /**
     * Un mob es jefe si: esta en el tag forge:bosses, o cualquiera de sus tags se llama
     * "boss" / "bosses" / "..._boss", o su propio id se llama "boss" / "..._boss".
     */
    public static boolean isBoss(EntityType<?> type) {
        if (type.is(Tags.EntityTypes.BOSSES)) return true;
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(type);
        if (id != null && isBossName(id.getPath())) return true;
        return type.builtInRegistryHolder().tags().anyMatch(t -> isBossName(t.location().getPath()));
    }

    private static boolean isBossName(String path) {
        int slash = path.lastIndexOf('/');
        String n = slash >= 0 ? path.substring(slash + 1) : path;
        return n.equals("boss") || n.equals("bosses") || n.endsWith("_boss") || n.endsWith("_bosses");
    }

    public static boolean isVanillaBoss(EntityType<?> type) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(type);
        return id != null && id.getNamespace().equals("minecraft") && isBoss(type);
    }

    /**
     * Nivel maximo de una entidad. Prioridad:
     * 1) valor personalizado por comando (/mobevolution config mob <mob> maxlevel)
     * 2) Warden = 1
     * 3) jefe de Minecraft = vanillaBossMaxLevel (80), jefe de otro mod = modBossMaxLevel (30)
     * 4) cualquier otro mob = maxMobLevel
     */
    public static int maxLevel(EntityType<?> type) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(type);
        if (id != null) {
            Integer custom = MobOverrides.maxLevel(id);
            if (custom != null) return custom;
            if (id.equals(WARDEN)) return 1;
        }
        int global = Config.MAX_LEVEL.get();
        if (!isBoss(type)) return global;
        boolean vanilla = id != null && id.getNamespace().equals("minecraft");
        int cap = vanilla ? Config.VANILLA_BOSS_MAX.get() : Config.MOD_BOSS_MAX.get();
        return Math.min(global, cap);
    }
}
