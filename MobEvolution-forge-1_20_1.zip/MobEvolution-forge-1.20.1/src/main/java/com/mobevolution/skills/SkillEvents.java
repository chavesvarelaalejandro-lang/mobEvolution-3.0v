package com.mobevolution.skills;

import com.mobevolution.MobEvolution;
import com.mobevolution.network.Network;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;

public class SkillEvents {

    @Mod.EventBusSubscriber(modid = MobEvolution.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ModBus {
        @SubscribeEvent
        public static void registerCaps(RegisterCapabilitiesEvent e) {
            e.register(PlayerSkills.class);
        }
    }

    @SubscribeEvent
    public void attach(AttachCapabilitiesEvent<Entity> e) {
        if (e.getObject() instanceof Player) {
            e.addCapability(new ResourceLocation(MobEvolution.MODID, "skills"), new PlayerSkillsProvider());
        }
    }

    @SubscribeEvent
    public void clone(PlayerEvent.Clone e) {
        e.getOriginal().reviveCaps();
        e.getOriginal().getCapability(PlayerSkillsProvider.CAP).ifPresent(old ->
                e.getEntity().getCapability(PlayerSkillsProvider.CAP).ifPresent(neu -> neu.copyFrom(old)));
        e.getOriginal().invalidateCaps();
    }

    @SubscribeEvent
    public void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) refresh(sp);
    }

    @SubscribeEvent
    public void respawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            refresh(sp);
            if (!e.isEndConquered()) sp.setHealth(sp.getMaxHealth());
        }
    }

    @SubscribeEvent
    public void dimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) refresh(sp);
    }

    @SubscribeEvent
    public void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer sp)) return;
        if (sp.tickCount % 20 != 0) return;
        sp.getCapability(PlayerSkillsProvider.CAP).ifPresent(s -> {
            if (s.awardFromXpLevel(sp.experienceLevel)) Network.sync(sp);
        });
    }

    public static void refresh(ServerPlayer sp) {
        SkillEffects.apply(sp);
        Network.sync(sp);
    }
}
