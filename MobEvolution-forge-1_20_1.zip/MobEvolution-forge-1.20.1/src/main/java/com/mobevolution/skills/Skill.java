package com.mobevolution.skills;

import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;

public enum Skill {
    VITALITY("Vitalidad", "+1 corazon por nivel", 20, () -> Attributes.MAX_HEALTH, 2.0, Operation.ADDITION,
            "7c1e2f10-3a4b-4c5d-8e6f-0a1b2c3d4e01"),
    STRENGTH("Fuerza", "+0.5 de dano por nivel", 20, () -> Attributes.ATTACK_DAMAGE, 0.5, Operation.ADDITION,
            "7c1e2f10-3a4b-4c5d-8e6f-0a1b2c3d4e02"),
    AGILITY("Agilidad", "+2% velocidad por nivel", 15, () -> Attributes.MOVEMENT_SPEED, 0.02, Operation.MULTIPLY_BASE,
            "7c1e2f10-3a4b-4c5d-8e6f-0a1b2c3d4e03"),
    RESISTANCE("Resistencia", "+0.5 armadura por nivel", 20, () -> Attributes.ARMOR, 0.5, Operation.ADDITION,
            "7c1e2f10-3a4b-4c5d-8e6f-0a1b2c3d4e04"),
    LUCK("Suerte", "+0.25 suerte por nivel", 10, () -> Attributes.LUCK, 0.25, Operation.ADDITION,
            "7c1e2f10-3a4b-4c5d-8e6f-0a1b2c3d4e05");

    public final String displayName;
    public final String description;
    public final int maxLevel;
    public final double perLevel;
    public final Operation op;
    public final UUID uuid;
    private final Supplier<Attribute> attribute;

    Skill(String name, String desc, int max, Supplier<Attribute> attr, double perLevel, Operation op, String uuid) {
        this.displayName = name;
        this.description = desc;
        this.maxLevel = max;
        this.attribute = attr;
        this.perLevel = perLevel;
        this.op = op;
        this.uuid = UUID.fromString(uuid);
    }

    public Attribute attribute() {
        return attribute.get();
    }
}
