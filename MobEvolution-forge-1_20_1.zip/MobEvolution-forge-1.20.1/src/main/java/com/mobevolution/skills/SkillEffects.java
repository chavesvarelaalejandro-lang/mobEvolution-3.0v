package com.mobevolution.skills;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;

public final class SkillEffects {
    private SkillEffects() {}

    /** Aplica las habilidades como modificadores de atributo con UUID propio (compatible con otros mods). */
    public static void apply(ServerPlayer p) {
        p.getCapability(PlayerSkillsProvider.CAP).ifPresent(skills -> {
            for (Skill s : Skill.values()) {
                AttributeInstance inst = p.getAttribute(s.attribute());
                if (inst == null) continue;
                inst.removeModifier(s.uuid);
                int lvl = skills.getLevel(s);
                if (lvl > 0) {
                    inst.addTransientModifier(new AttributeModifier(
                            s.uuid, "mobevolution_" + s.name().toLowerCase(), s.perLevel * lvl, s.op));
                }
            }
            if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
        });
    }
}
