package com.mobevolution.skills;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlayerSkillsProvider implements ICapabilitySerializable<CompoundTag> {
    public static final Capability<PlayerSkills> CAP = CapabilityManager.get(new CapabilityToken<>() {});

    private final PlayerSkills skills = new PlayerSkills();
    private final LazyOptional<PlayerSkills> opt = LazyOptional.of(() -> skills);

    @NotNull
    @Override
    public <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        return cap == CAP ? opt.cast() : LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() { return skills.serializeNBT(); }

    @Override
    public void deserializeNBT(CompoundTag nbt) { skills.deserializeNBT(nbt); }
}
