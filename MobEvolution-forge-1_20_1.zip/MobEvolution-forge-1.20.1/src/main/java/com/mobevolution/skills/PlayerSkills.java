package com.mobevolution.skills;

import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.util.INBTSerializable;

public class PlayerSkills implements INBTSerializable<CompoundTag> {
    private final int[] levels = new int[Skill.values().length];
    private int points = 0;
    private int maxXpLevelReached = 0;

    public int getLevel(Skill s) { return levels[s.ordinal()]; }
    public int getPoints() { return points; }

    public int totalLevels() {
        int t = 0;
        for (int l : levels) t += l;
        return t;
    }

    /** Puntos ganados en total (gastados + sin gastar). */
    public int totalEarned() { return totalLevels() + points; }

    public boolean canUpgrade(Skill s) {
        return points > 0 && levels[s.ordinal()] < s.maxLevel;
    }

    public boolean tryUpgrade(Skill s) {
        if (!canUpgrade(s)) return false;
        levels[s.ordinal()]++;
        points--;
        return true;
    }

    /** 1 punto por cada nivel de XP nuevo alcanzado (gastar niveles en encantar no da puntos extra). */
    public boolean awardFromXpLevel(int xpLevel) {
        if (xpLevel <= maxXpLevelReached) return false;
        points += xpLevel - maxXpLevelReached;
        maxXpLevelReached = xpLevel;
        return true;
    }

    public void copyFrom(PlayerSkills o) {
        System.arraycopy(o.levels, 0, levels, 0, levels.length);
        points = o.points;
        maxXpLevelReached = o.maxXpLevelReached;
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag t = new CompoundTag();
        for (Skill s : Skill.values()) t.putInt(s.name(), levels[s.ordinal()]);
        t.putInt("points", points);
        t.putInt("maxXp", maxXpLevelReached);
        return t;
    }

    @Override
    public void deserializeNBT(CompoundTag t) {
        for (Skill s : Skill.values()) levels[s.ordinal()] = Math.min(t.getInt(s.name()), s.maxLevel);
        points = t.getInt("points");
        maxXpLevelReached = t.getInt("maxXp");
    }
}
