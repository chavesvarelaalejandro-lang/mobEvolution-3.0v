# Mob Evolution (Forge 1.20.1)

## Como compilarlo
1. Descarga el MDK de Forge 1.20.1 (47.3.0 o superior): https://files.minecraftforge.net/
2. Descomprimelo y BORRA su carpeta `src/main/java/com/example`.
3. Copia la carpeta `src` de este proyecto encima de la `src` del MDK
   (sustituye `META-INF/mods.toml` y `pack.mcmeta`).
4. En `gradle.properties` del MDK pon:
       mod_id=mobevolution
       mod_name=Mob Evolution
       mod_group_id=com.mobevolution
       mod_version=1.0.0
5. Necesitas JDK 17. Ejecuta `./gradlew build` (o `gradlew.bat build` en Windows).
6. El .jar queda en `build/libs/`. Metelo en la carpeta `mods` (cliente y servidor).

## Configuracion
`config/mobevolution-common.toml` (se genera al primer arranque).

## Comandos (requieren ser operador, nivel 2)

### Dias / nivel minimo
| Comando | Que hace |
|---|---|
| `/mobevolution days get` | Muestra dias reales, desplazamiento, dias efectivos y nivel minimo/maximo actual |
| `/mobevolution days reset` | Reinicia los dias efectivos a 0 (nivel minimo 1) |
| `/mobevolution days add <dias>` | Suma (o resta, con negativo) dias |
| `/mobevolution days set <dias>` | Fija los dias efectivos |
| `/mobevolution days minlevel <nivel>` | Fija los dias para que el nivel minimo sea exactamente ese |

No cambia la hora real del mundo: guarda un desplazamiento en el mundo. Solo afecta a los mobs que aparezcan despues.

### Configuracion de estadisticas por nivel
| Comando | Que hace |
|---|---|
| `/mobevolution config global` | Muestra los coeficientes globales |
| `/mobevolution config global <health\|damage\|speed\|armor> <valor>` | Cambia el coeficiente global (se guarda en el .toml) |
| `/mobevolution config list [pagina]` | Lista TODOS los mobs (vanilla + mods), con clic para configurar |
| `/mobevolution config search <texto> [pagina]` | Busca mobs por nombre/mod |
| `/mobevolution config mob <mob>` | Muestra la configuracion efectiva de ese mob |
| `/mobevolution config mob <mob> <health\|damage\|speed\|armor> <valor>` | Coeficiente individual (`... reset` para volver al global) |
| `/mobevolution config mob <mob> maxlevel <nivel>` | Nivel maximo de ese mob (`... maxlevel reset` para volver al de por defecto) |
| `/mobevolution config mob <mob> reset` | Borra toda la config individual del mob |
| `/mobevolution config reload` | Recarga `config/mobevolution-mobs.json` |

El argumento `<mob>` autocompleta con todos los mobs registrados (pulsa TAB).
La config individual se guarda en `config/mobevolution-mobs.json`.

### Niveles maximos de jefes
* Jefes de Minecraft: **80** (`vanillaBossMaxLevel` en el .toml)
* **Warden**: siempre nivel **1**
* Jefes de otros mods: **30** (`modBossMaxLevel`); se cambia jefe a jefe con `config mob <mob> maxlevel <nivel>`
* Un mob es jefe si esta en el tag `forge:bosses`, si alguno de sus tags se llama `boss`/`bosses`/`..._boss`, o si su id es `boss`/`..._boss`.
